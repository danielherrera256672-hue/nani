package com.local.ofertas;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.os.Build;
import android.os.IBinder;
import android.provider.Settings;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

/** Semaforo flotante: no califica ofertas hasta leer TODOS los campos. */
public class OverlayService extends Service {
    private static final String CHANNEL="ofertas_activas";
    private WindowManager wm;
    private WindowManager.LayoutParams params;
    private View overlay;
    private EditText fare,pickup,trip,minutes;
    private TextView result,compactVerdict,sourceStatus;
    private ScrollView scroll;
    private Button collapse,manualButton,resumeButton;
    private boolean minimized=true,manualMode=false;
    private BroadcastReceiver receiver;
    private String lastOffer="";

    @Override public void onCreate(){
        super.onCreate();
        NotificationManager nm=getSystemService(NotificationManager.class);
        nm.createNotificationChannel(new NotificationChannel(CHANNEL,"Analizador de ofertas",
            NotificationManager.IMPORTANCE_LOW));
        PendingIntent pi=PendingIntent.getActivity(this,0,new Intent(this,MainActivity.class),
            PendingIntent.FLAG_IMMUTABLE|PendingIntent.FLAG_UPDATE_CURRENT);
        Notification n=new Notification.Builder(this,CHANNEL)
            .setSmallIcon(android.R.drawable.ic_menu_info_details)
            .setContentTitle("Analizador de viajes activo")
            .setContentText("Toca para configurar o detener la lectura")
            .setContentIntent(pi).setOngoing(true).build();
        if(Build.VERSION.SDK_INT>=34)startForeground(44,n,
            android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
        else startForeground(44,n);
        if(!Settings.canDrawOverlays(this)){stopSelf();return;}
        buildOverlay();
        receiver=new BroadcastReceiver(){
            @Override public void onReceive(Context c,Intent i){
                String action=i.getAction();
                if(CaptureService.ACTION_VISIBILITY.equals(action)){
                    if(overlay!=null)overlay.setVisibility(i.getBooleanExtra(
                        CaptureService.EXTRA_VISIBLE,true)?View.VISIBLE:View.INVISIBLE);
                }else if(CaptureService.ACTION_OCR_STARTED.equals(action)){
                    manualMode=false;setMinimized(true);clearFields();
                    compactVerdict.setText("OCR activo · Esperando oferta");
                    compactVerdict.setTextColor(Ui.NAVY);
                }else if(CaptureService.ACTION_RESULT.equals(action))onRead(i);
            }
        };
        IntentFilter f=new IntentFilter();
        f.addAction(CaptureService.ACTION_VISIBILITY);
        f.addAction(CaptureService.ACTION_OCR_STARTED);
        f.addAction(CaptureService.ACTION_RESULT);
        if(Build.VERSION.SDK_INT>=33)registerReceiver(receiver,f,Context.RECEIVER_NOT_EXPORTED);
        else registerReceiver(receiver,f);
    }
    private EditText field(LinearLayout parent,String label){
        parent.addView(Ui.label(this,label,12,true));
        EditText e=Ui.decimal(this,"");e.setTextSize(15);
        e.setHint("Pendiente de lectura");
        e.setOnFocusChangeListener((v,hasFocus)->{
            if(hasFocus && !manualMode){
                manualMode=true;
                compactVerdict.setText("Modo manual · Completa los datos");
                compactVerdict.setTextColor(Ui.AMBER);
            }
        });
        parent.addView(e,new LinearLayout.LayoutParams(-1,Ui.dp(this,42)));
        return e;
    }
    private void buildOverlay(){
        wm=(WindowManager)getSystemService(WINDOW_SERVICE);
        LinearLayout panel=Ui.column(this,11);
        panel.setBackground(Ui.background(Color.WHITE,14,this));
        panel.setElevation(Ui.dp(this,12));
        LinearLayout heading=new LinearLayout(this);
        heading.setOrientation(LinearLayout.HORIZONTAL);
        TextView title=Ui.label(this,"  Evaluar oferta  ≡",16,true);
        heading.addView(title,new LinearLayout.LayoutParams(0,Ui.dp(this,42),1));
        collapse=Ui.button(this,"+");
        heading.addView(collapse,new LinearLayout.LayoutParams(Ui.dp(this,48),Ui.dp(this,42)));
        panel.addView(heading);
        compactVerdict=Ui.label(this,"Esperando lectura OCR",14,true);
        compactVerdict.setPadding(Ui.dp(this,6),0,Ui.dp(this,6),Ui.dp(this,8));
        panel.addView(compactVerdict);
        LinearLayout details=Ui.column(this,0);
        details.addView(Ui.label(this,"Valores reconocidos; revisa antes de aceptar un viaje.",12,false));
        sourceStatus=Ui.label(this,"Tarifa: —  ·  Recogida: —  ·  Viaje: —",12,false);
        details.addView(sourceStatus);
        fare=field(details,"Tarifa ofrecida (COP)");
        pickup=field(details,"Distancia hasta el pasajero (km)");
        trip=field(details,"Distancia del viaje (km)");
        minutes=field(details,"Minutos totales, incluyendo recogida");
        Button calculate=Ui.button(this,"Analizar datos ingresados");
        details.addView(calculate);
        result=Ui.label(this,"Sin lectura completa. El resultado no se calcula automaticamente.",13,true);
        result.setPadding(Ui.dp(this,6),Ui.dp(this,9),Ui.dp(this,6),Ui.dp(this,10));
        result.setTextColor(Ui.AMBER);
        details.addView(result);
        manualButton=Ui.button(this,"Activar modo manual");
        resumeButton=Ui.button(this,"Reanudar lectura OCR");
        details.addView(manualButton);details.addView(resumeButton);
        Button close=Ui.button(this,"Cerrar ventana");details.addView(close);
        scroll=new ScrollView(this);scroll.addView(details);
        int height=getResources().getDisplayMetrics().heightPixels;
        scroll.setLayoutParams(new LinearLayout.LayoutParams(-1,
            Math.min(Ui.dp(this,495),(int)(height*.66f))));
        panel.addView(scroll);
        calculate.setOnClickListener(v->{manualMode=true;analyze(true);});
        manualButton.setOnClickListener(v->{manualMode=true;
            compactVerdict.setText("Modo manual · Verifica la oferta");
            compactVerdict.setTextColor(Ui.AMBER);setMinimized(false);
        });
        resumeButton.setOnClickListener(v->{manualMode=false;lastOffer="";clearFields();
            compactVerdict.setText("Esperando lectura completa...");
            compactVerdict.setTextColor(Ui.NAVY);
        });
        close.setOnClickListener(v->{
            stopService(new Intent(this,CaptureService.class));
            stopSelf();
        });
        collapse.setOnClickListener(v->setMinimized(!minimized));
        params=new WindowManager.LayoutParams(Ui.dp(this,300),
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL|
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT);
        params.gravity=Gravity.TOP|Gravity.START;
        params.x=Ui.dp(this,8);params.y=Ui.dp(this,62);
        overlay=panel;
        title.setOnTouchListener(new View.OnTouchListener(){
            int ix,iy;float sx,sy;
            @Override public boolean onTouch(View v,MotionEvent event){
                if(event.getAction()==MotionEvent.ACTION_DOWN){
                    ix=params.x;iy=params.y;sx=event.getRawX();sy=event.getRawY();return true;
                }
                if(event.getAction()==MotionEvent.ACTION_MOVE){
                    params.x=ix+(int)(event.getRawX()-sx);
                    params.y=iy+(int)(event.getRawY()-sy);
                    if(overlay!=null)wm.updateViewLayout(overlay,params);
                    return true;
                }
                return event.getAction()==MotionEvent.ACTION_UP;
            }
        });
        wm.addView(overlay,params);
        setMinimized(true);
    }
    private void setMinimized(boolean state){
        minimized=state;
        if(scroll!=null)scroll.setVisibility(state?View.GONE:View.VISIBLE);
        if(collapse!=null)collapse.setText(state?"+":"−");
        if(params!=null&&overlay!=null&&wm!=null){
            if(state)params.flags|=WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE;
            else params.flags&=~WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE;
            try{wm.updateViewLayout(overlay,params);}catch(Exception ignored){}
        }
    }
    private void clearFields(){
        if(fare==null)return;
        fare.setText("");pickup.setText("");trip.setText("");minutes.setText("");
        lastOffer="";
        sourceStatus.setText("Tarifa: — · Recogida: — · Viaje: —");
        result.setText("Sin lectura completa. No hay evaluacion automatica.");
        result.setTextColor(Ui.AMBER);
    }
    private void readValue(EditText edit,Intent i,String key){
        if(i.hasExtra(key))edit.setText(Ui.one(i.getDoubleExtra(key,0)));
        else edit.setText("");
    }
    private String visibleValue(Intent i,String key,String unit){
        return i.hasExtra(key)?Ui.one(i.getDoubleExtra(key,0))+" "+unit:"—";
    }
    private void onRead(Intent i){
        if(manualMode)return;
        boolean visible=i.getBooleanExtra("offerVisible",false);
        if(!visible){
            clearFields();
            compactVerdict.setText("Buscando oferta visible...");
            compactVerdict.setTextColor(Ui.NAVY);
            return;
        }
        readValue(fare,i,"fare");readValue(pickup,i,"pickup");
        readValue(trip,i,"trip");readValue(minutes,i,"minutes");
        sourceStatus.setText("Tarifa: "+visibleValue(i,"fare","COP")+
            " · Recogida: "+visibleValue(i,"pickup","km")+" / "+
            visibleValue(i,"pickupMinutes","min")+" · Viaje: "+
            visibleValue(i,"trip","km")+" / "+visibleValue(i,"tripMinutes","min"));
        if(!i.getBooleanExtra("complete",false)){
            lastOffer="";
            compactVerdict.setText("OCR parcial · Pulsa + para revisar");
            compactVerdict.setTextColor(Ui.AMBER);
            result.setText(String.valueOf(i.getStringExtra("warning"))+". Verifica lo reconocido o completa los datos manualmente.");
            result.setTextColor(Ui.AMBER);
            return;
        }
        String fingerprint=visibleValue(i,"fare","")+"|"+
            visibleValue(i,"pickup","")+"|"+visibleValue(i,"trip","")+"|"+
            visibleValue(i,"minutes","");
        if(fingerprint.equals(lastOffer))return;
        lastOffer=fingerprint;
        analyze(false);
    }
    private void analyze(boolean manual){
        double f=Ui.number(fare),k=Ui.number(pickup),t=Ui.number(trip),m=Ui.number(minutes);
        if(!Ui.valid(f)||!Ui.valid(k)||!Ui.valid(t)||!Ui.valid(m)||f<=0||t<=0||m<=0){
            result.setText("Faltan valores validos. Revisa tarifa, km de recogida, km del viaje y tiempo total.");
            result.setTextColor(Ui.AMBER);
            compactVerdict.setText("SIN DATOS SUFICIENTES");
            compactVerdict.setTextColor(Ui.AMBER);
            if(manual)Toast.makeText(this,"Completa los cuatro campos",Toast.LENGTH_LONG).show();
            return;
        }
        ProfitEngine.Offer o=new ProfitEngine.Offer();
        o.fare=f;o.pickupKm=k;o.tripKm=t;o.totalMinutes=m;
        ProfitEngine.Config config=Prefs.read(this);
        ProfitEngine.Result r=ProfitEngine.calculate(config,o);
        int color=r.verdict.equals("RENTABLE")?Ui.GREEN:r.verdict.equals("MARGINAL")?Ui.AMBER:Ui.RED;
        result.setText("● "+r.verdict+(manual?" (MANUAL)":" (OCR)")+"\n"+
            "Utilidad operativa estimada: "+Ui.money(r.operatingProfit)+"\n"+
            "Utilidad despues de costo del tiempo: "+Ui.money(r.profit)+"\n"+
            "Utilidad por km: "+Ui.money(r.profitPerKm)+"\n"+
            "Utilidad por hora: "+Ui.money(r.profitPerHour)+"\n"+
            "Recorrido: "+Ui.one(r.totalKm)+" km\n"+
            "Gasolina: "+Ui.money(r.fuelCost)+"\n"+
            "Mantenimiento: "+Ui.money(r.maintenanceCost)+"\n"+
            "Seguros, SOAT, revision y llantas: "+Ui.money(r.otherFixedCost)+"\n"+
            "Comision: "+Ui.money(r.commission)+"\n"+
            "Tarifa minima objetivo: "+Ui.money(r.minimumFareForTargets)+"\n"+
            "Revisa la oferta antes de aceptarla.");
        result.setTextColor(color);
        result.setBackground(Ui.background(Color.rgb(245,247,249),9,this));
        compactVerdict.setText("● "+r.verdict+" · "+Ui.money(r.profit)+" aprox.");
        compactVerdict.setTextColor(color);
    }
    @Override public int onStartCommand(Intent i,int flags,int startId){return START_STICKY;}
    @Override public void onDestroy(){
        // Si desaparece el panel, detener tambien la captura de pantalla.
        stopService(new Intent(this,CaptureService.class));
        if(receiver!=null)try{unregisterReceiver(receiver);}catch(Exception ignored){}
        if(wm!=null&&overlay!=null)try{wm.removeView(overlay);}catch(Exception ignored){}
        super.onDestroy();
    }
    @Override public IBinder onBind(Intent i){return null;}
}
