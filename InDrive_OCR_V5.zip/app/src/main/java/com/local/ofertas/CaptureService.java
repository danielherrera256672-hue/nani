package com.local.ofertas;

import android.app.Activity;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.Rect;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.Image;
import android.media.ImageReader;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.util.DisplayMetrics;
import android.view.WindowManager;
import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.Text;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.TextRecognizer;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.List;

/** OCR local con coordenadas + segunda lectura ampliada del mapa y la tarifa. */
public class CaptureService extends Service {
    public static final String ACTION_RESULT="com.local.ofertas.OCR_RESULT";
    public static final String ACTION_OCR_STARTED="com.local.ofertas.OCR_STARTED";
    public static final String ACTION_VISIBILITY="com.local.ofertas.OVERLAY_VISIBILITY";
    public static final String EXTRA_VISIBLE="visible";
    private final Handler handler=new Handler(Looper.getMainLooper());
    private MediaProjection projection;
    private VirtualDisplay display;
    private ImageReader reader;
    private TextRecognizer recognizer;
    private boolean running=false,busy=false;
    private final Runnable loop=new Runnable(){
        @Override public void run(){
            if(!running)return;
            if(busy){handler.postDelayed(this,850);return;}
            setOverlayVisible(false);
            // Esperar que desaparezca de verdad el overlay antes de obtener el fotograma.
            handler.postDelayed(()->{if(running)captureFrame();},450);
            handler.postDelayed(this,2800);
        }
    };
    @Override public void onCreate(){
        super.onCreate();
        NotificationManager nm=getSystemService(NotificationManager.class);
        nm.createNotificationChannel(new NotificationChannel("captura_ofertas",
            "Lectura local de pantalla",NotificationManager.IMPORTANCE_LOW));
        recognizer=TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS);
    }
    @Override public int onStartCommand(Intent intent,int flags,int startId){
        if(running) return START_NOT_STICKY;
        if(intent==null || !intent.hasExtra("resultData")) {stopSelf();return START_NOT_STICKY;}
        Notification n=new Notification.Builder(this,"captura_ofertas")
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .setContentTitle("Lectura de ofertas activa")
            .setContentText("OCR local de pantalla. Detener desde la aplicación.")
            .setOngoing(true).build();
        try {
            if(Build.VERSION.SDK_INT>=29)startForeground(45,n,
                android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION);
            else startForeground(45,n);
            MediaProjectionManager manager=(MediaProjectionManager)getSystemService(MEDIA_PROJECTION_SERVICE);
            projection=manager.getMediaProjection(intent.getIntExtra("resultCode",Activity.RESULT_CANCELED),
                (Intent)intent.getParcelableExtra("resultData"));
            if(projection==null){stopSelf();return START_NOT_STICKY;}
            projection.registerCallback(new MediaProjection.Callback(){
                @Override public void onStop(){stopSelf();}
            },handler);
            DisplayMetrics metrics=new DisplayMetrics();
            ((WindowManager)getSystemService(WINDOW_SERVICE)).getDefaultDisplay().getRealMetrics(metrics);
            reader=ImageReader.newInstance(metrics.widthPixels,metrics.heightPixels,
                PixelFormat.RGBA_8888,2);
            display=projection.createVirtualDisplay("ocr_local_vivo",metrics.widthPixels,
                metrics.heightPixels,metrics.densityDpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                reader.getSurface(),null,handler);
            running=true;
            sendBroadcast(new Intent(ACTION_OCR_STARTED).setPackage(getPackageName()));
            handler.post(loop);
        }catch(Exception e){broadcastError("No se pudo iniciar captura; vuelve a autorizar la pantalla");stopSelf();}
        return START_NOT_STICKY;
    }
    private void setOverlayVisible(boolean show){
        Intent i=new Intent(ACTION_VISIBILITY).setPackage(getPackageName());
        i.putExtra(EXTRA_VISIBLE,show);sendBroadcast(i);
    }
    private void broadcastError(String message){
        Intent i=new Intent(ACTION_RESULT).setPackage(getPackageName());
        i.putExtra("complete",false).putExtra("offerVisible",false).putExtra("warning",message);
        sendBroadcast(i);
    }
    private void broadcast(OfferParser.Parsed p){
        Intent i=new Intent(ACTION_RESULT).setPackage(getPackageName());
        i.putExtra("complete",p.complete());i.putExtra("offerVisible",p.offerVisible);
        i.putExtra("warning",p.warning);i.putExtra("missing",p.missing());
        if(p.fare!=null)i.putExtra("fare",p.fare);
        if(p.pickupKm!=null)i.putExtra("pickup",p.pickupKm);
        if(p.tripKm!=null)i.putExtra("trip",p.tripKm);
        if(p.pickupMinutes!=null)i.putExtra("pickupMinutes",p.pickupMinutes);
        if(p.tripMinutes!=null)i.putExtra("tripMinutes",p.tripMinutes);
        if(p.minutes!=null)i.putExtra("minutes",p.minutes);
        sendBroadcast(i);
    }
    private void done(Bitmap frame){
        if(frame!=null && !frame.isRecycled())frame.recycle();
        busy=false;
    }
    private void captureFrame(){
        if(reader==null || busy){setOverlayVisible(true);return;}
        Image image=null;Bitmap padded=null;
        try{
            image=reader.acquireLatestImage();
            if(image==null){setOverlayVisible(true);return;}
            Image.Plane plane=image.getPlanes()[0];
            int width=image.getWidth(),height=image.getHeight();
            int stride=plane.getRowStride(),pixelStride=plane.getPixelStride();
            ByteBuffer buffer=plane.getBuffer();
            padded=Bitmap.createBitmap(stride/pixelStride,height,Bitmap.Config.ARGB_8888);
            padded.copyPixelsFromBuffer(buffer);
            final Bitmap frame=Bitmap.createBitmap(padded,0,0,width,height);
            padded.recycle();padded=null;
            image.close();image=null;
            setOverlayVisible(true);
            busy=true;
            recognizer.process(InputImage.fromBitmap(frame,0)).addOnCompleteListener(task->{
                try {
                    if(!task.isSuccessful()){
                        broadcastError("Error OCR. Reinicia la lectura de pantalla");done(frame);return;
                    }
                    List<OfferParser.ScreenLine> lines=collect(task.getResult(),frame,0,0,1f);
                    OfferParser.Parsed first=OfferParser.parseScreen(lines,frame.getWidth(),frame.getHeight());
                    if(first.complete()){broadcast(first);done(frame);return;}
                    // Los números pequeños del mapa se vuelven a leer a 2x.
                    scanCrop(frame,lines,.055f,.355f,2.35f,false);
                }catch(Exception e){broadcastError("Error al interpretar la captura");done(frame);}
            });
        }catch(Exception e){setOverlayVisible(true);broadcastError("No se pudo obtener la pantalla");busy=false;}
        finally{if(image!=null)image.close();if(padded!=null)padded.recycle();}
    }
    private void scanCrop(Bitmap frame,List<OfferParser.ScreenLine> initial,
                          float from,float to,float scale,boolean last){
        int y=Math.max(0,(int)(frame.getHeight()*from));
        int h=Math.min(frame.getHeight()-y,(int)(frame.getHeight()*(to-from)));
        if(h<=0){broadcast(OfferParser.parseScreen(initial,frame.getWidth(),frame.getHeight()));done(frame);return;}
        final Bitmap crop=Bitmap.createBitmap(frame,0,y,frame.getWidth(),h);
        final Bitmap larger=Bitmap.createScaledBitmap(crop,
            (int)(crop.getWidth()*scale),(int)(crop.getHeight()*scale),true);
        crop.recycle();
        recognizer.process(InputImage.fromBitmap(larger,0)).addOnCompleteListener(task->{
            try{
                if(task.isSuccessful())initial.addAll(collect(task.getResult(),frame,0,y,scale));
                OfferParser.Parsed parsed=OfferParser.parseScreen(initial,frame.getWidth(),frame.getHeight());
                if(parsed.complete() || last){broadcast(parsed);done(frame);}
                else scanCrop(frame,initial,.365f,.745f,1.65f,true);
            }catch(Exception e){broadcastError("No se pudo analizar la oferta");done(frame);}
            finally{larger.recycle();}
        });
    }
    private List<OfferParser.ScreenLine> collect(Text recognized,Bitmap frame,
                           int dx,int dy,float scale){
        List<OfferParser.ScreenLine> out=new ArrayList<>();
        for(Text.TextBlock block:recognized.getTextBlocks()){
            for(Text.Line line:block.getLines()){
                Rect b=line.getBoundingBox();if(b==null)continue;
                Rect rect=new Rect(dx+(int)(b.left/scale),dy+(int)(b.top/scale),
                    dx+(int)(b.right/scale),dy+(int)(b.bottom/scale));
                out.add(new OfferParser.ScreenLine(line.getText(),rect.left,rect.top,
                    rect.right,rect.bottom,findBackgroundColor(frame,rect)));
                // En algunos equipos el precio queda separado en elementos OCR.
                if(line.getElements().size()>1){
                    for(Text.Element el:line.getElements()){
                        Rect e=el.getBoundingBox();if(e==null)continue;
                        Rect er=new Rect(dx+(int)(e.left/scale),dy+(int)(e.top/scale),
                            dx+(int)(e.right/scale),dy+(int)(e.bottom/scale));
                        out.add(new OfferParser.ScreenLine(el.getText(),er.left,er.top,
                            er.right,er.bottom,findBackgroundColor(frame,er)));
                    }
                }
            }
        }
        return out;
    }
    private int findBackgroundColor(Bitmap bitmap,Rect r){
        // Muestrea alrededor y dentro de la caja OCR para detectar los fondos
        // azul (recogida) y verde lima (trayecto), sin depender de textos A/B.
        int w=bitmap.getWidth(),h=bitmap.getHeight();
        int x=(r.left+r.right)/2,y=(r.top+r.bottom)/2;
        int[] xx={r.left-4,r.left+2,r.right-2,r.right+4,x,x};
        int[] yy={y,r.top+2,r.bottom-2,y,r.top-3,r.bottom+3};
        int blue=0,lime=0;
        float[] hsv=new float[3];
        for(int i=0;i<xx.length;i++){
            int sx=Math.max(0,Math.min(w-1,xx[i]));
            int sy=Math.max(0,Math.min(h-1,yy[i]));
            Color.colorToHSV(bitmap.getPixel(sx,sy),hsv);
            if(hsv[1]>.30f && hsv[2]>.42f){
                if(hsv[0]>=183f&&hsv[0]<=257f)blue++;
                if(hsv[0]>=48f&&hsv[0]<=99f && hsv[2]>.55f)lime++;
            }
        }
        if(blue>=3 && blue>lime)return OfferParser.COLOR_BLUE;
        if(lime>=3 && lime>blue)return OfferParser.COLOR_LIME;
        return OfferParser.COLOR_UNKNOWN;
    }
    @Override public void onDestroy(){
        running=false;handler.removeCallbacksAndMessages(null);setOverlayVisible(true);
        if(display!=null)display.release();
        if(reader!=null)reader.close();
        if(projection!=null)projection.stop();
        if(recognizer!=null)recognizer.close();
        super.onDestroy();
    }
    @Override public IBinder onBind(Intent i){return null;}
}
