package com.local.ofertas;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Conservative, offline parser for the driver's visible offer sheet.
 * Screen positions are normalized so OCR order and phone resolution do not matter.
 * A missing or ambiguous field NEVER becomes a fabricated profit verdict.
 * Pure Java, allowing tests without Android or ML Kit installed.
 */
public final class OfferParser {
    private OfferParser() {}
    public static final int COLOR_UNKNOWN = 0;
    public static final int COLOR_BLUE = 1;
    public static final int COLOR_LIME = 2;

    public static final class ScreenLine {
        public final String text;
        public final int left,top,right,bottom,color;
        public ScreenLine(String text,int left,int top,int right,int bottom,int color) {
            this.text = text == null ? "" : text.trim();
            this.left=left;this.top=top;this.right=right;this.bottom=bottom;this.color=color;
        }
        public int x(){return (left+right)/2;}
        public int y(){return (top+bottom)/2;}
    }

    public static final class Parsed {
        public Double fare,pickupKm,tripKm,minutes,pickupMinutes,tripMinutes;
        public boolean offerVisible,ambiguous;
        public String warning="";
        public boolean complete() {
            return offerVisible && !ambiguous && fare!=null && fare>0 &&
                pickupKm!=null && pickupKm>=0 && tripKm!=null && tripKm>0 &&
                pickupMinutes!=null && pickupMinutes>0 && tripMinutes!=null &&
                tripMinutes>0 && minutes!=null && minutes>0;
        }
        public String missing() {
            List<String> list = new ArrayList<>();
            if(fare==null)list.add("tarifa principal");
            if(pickupKm==null)list.add("km de recogida");
            if(tripKm==null)list.add("km del viaje");
            if(pickupMinutes==null)list.add("min de recogida");
            if(tripMinutes==null)list.add("min del viaje");
            if(ambiguous)list.add("datos ambiguos");
            return list.isEmpty()?"ninguno":String.join(", ",list);
        }
        public int detected() {
            int n=0;
            if(fare!=null)n++;
            if(pickupKm!=null)n++;
            if(tripKm!=null)n++;
            if(pickupMinutes!=null)n++;
            if(tripMinutes!=null)n++;
            return n;
        }
    }

    private static final Pattern MONEY=Pattern.compile("(?iu)(?:C[O0]L\\s*[$S]|C[O0]P\\s*[$S]?|[$])\\s*([0-9][0-9., ]{2,14})");
    private static final Pattern BARE_FARE=Pattern.compile("(?<![0-9])([0-9]{1,3}[.,][0-9]{3})(?![0-9])");
    private static final Pattern KM=Pattern.compile("(?iu)([0-9]{1,3}(?:[.,][0-9]{1,2})?)\\s*k\\s*m\\b");
    private static final Pattern MIN=Pattern.compile("(?iu)([0-9]{1,3})\\s*m\\s*i\\s*n(?:utos?)?\\b");
    private static final Pattern MARKER=Pattern.compile("(?iu)solicitud\\s+de\\s+viaje|aceptar\\s+por|precio\\s+justo|ofrece?\\s+tu\\s+tarifa");
    private static final Pattern COUNTER=Pattern.compile("(?iu)ofrece?\\s+tu\\s+tarifa|prop.{1,2}n\\s+tu\\s+tarifa");
    private static final Pattern CAUTION=Pattern.compile("(?iu)ten\\s+cuidado\\s+en\\s+esta\\s+ruta");

    private static Double decimal(String s) {
        try{return Double.valueOf(s.replace(',','.').trim());}
        catch(Exception ex){return null;}
    }
    private static Double fareNumber(String raw,boolean allowBare) {
        Matcher m=MONEY.matcher(raw);
        if(m.find())return parseFareDigits(m.group(1));
        if(allowBare){Matcher b=BARE_FARE.matcher(raw);if(b.find())return parseFareDigits(b.group(1));}
        return null;
    }
    private static Double parseFareDigits(String raw) {
        try {
            String s=raw.replace(" ","").trim();
            int sep=Math.max(s.lastIndexOf(','),s.lastIndexOf('.'));
            if(sep>=0 && s.length()-sep-1==3)s=s.replace(".","").replace(",","");
            else if(s.contains(".")&&s.contains(","))s=s.replace(".","").replace(",",".");
            else s=s.replace(',','.');
            double n=Double.parseDouble(s);
            return n>=1500 && n<=3000000 ? n : null;
        }catch(Exception ex){return null;}
    }
    private static List<Double> measurements(Pattern pattern,String raw,double min,double max){
        ArrayList<Double> out=new ArrayList<>();Matcher m=pattern.matcher(raw);
        while(m.find()){
            Double n=decimal(m.group(1));
            if(n!=null && n>=min && n<=max)out.add(n);
        }
        return out;
    }
    private static void status(Parsed p) {
        if(!p.offerVisible)p.warning="No se encontró una oferta visible";
        else if(p.ambiguous)p.warning="Lectura ambigua: comprobar los valores";
        else if(!p.complete())p.warning="OCR parcial ("+p.detected()+"/5). Faltan: "+p.missing();
        else p.warning="OCR completo (5/5). Comprueba los valores antes de decidir";
    }

    /** Compatibility: parses text in a known linear map-first order, never counteroffers. */
    public static Parsed parse(String raw) {
        Parsed p=new Parsed();
        if(raw==null){status(p);return p;}
        p.offerVisible=MARKER.matcher(raw).find();
        Matcher counter=COUNTER.matcher(raw);
        String card=counter.find()?raw.substring(0,counter.start()):raw;
        p.fare=fareNumber(card,false);
        Matcher caution=CAUTION.matcher(card);
        int cutoff=card.length();
        if(caution.find())cutoff=caution.start();
        else {Matcher money=MONEY.matcher(card);if(money.find())cutoff=money.start();}
        String map=card.substring(0,cutoff);
        List<Double> km=measurements(KM,map,0,250);
        List<Double> min=measurements(MIN,map,1,300);
        if(km.size()==2 && min.size()==2){
            p.pickupKm=km.get(0);p.tripKm=km.get(1);
            p.pickupMinutes=min.get(0);p.tripMinutes=min.get(1);
            p.minutes=p.pickupMinutes+p.tripMinutes;
        }
        if(!p.offerVisible)p.fare=null;
        status(p);return p;
    }

    private static boolean isNumber(String s){return s.matches("[0-9]{1,3}(?:[.,][0-9]{1,3})?");}
    private static boolean isUnit(String s){return s.matches("(?iu)k\\s*m|m\\s*i\\s*n(?:utos?)?");}
    private static boolean isCurrency(String s){return s.matches("(?iu)C[O0]L\\s*[$S]?|C[O0]P\\s*[$S]?|[$]");}
    private static boolean isCurrencySymbol(String s){return s.equals("$") || s.equalsIgnoreCase("S");}

    private static List<ScreenLine> augment(List<ScreenLine> source,int w,int h) {
        ArrayList<ScreenLine> augmented=new ArrayList<>();
        for(ScreenLine line:source) {
            if(line!=null && !line.text.isEmpty())augmented.add(line);
        }
        // OCR sometimes emits "COL", "$", and "21.800" as three elements.
        // Two deterministic passes join only compatible adjacent fragments.
        for(int pass=0;pass<2;pass++) {
            List<ScreenLine> scan=new ArrayList<>(augmented);
            List<ScreenLine> additions=new ArrayList<>();
            for(ScreenLine a:scan)for(ScreenLine b:scan) {
                if(a==b || a.text.isEmpty() || b.text.isEmpty())continue;
                if(Math.abs(a.y()-b.y())>h*.025)continue;
                ScreenLine left=a.left<=b.left?a:b;
                ScreenLine right=left==a?b:a;
                int gap=right.left-left.right;
                if(gap< -w*.012 || gap>w*.09)continue;
                String lt=left.text.trim(),rt=right.text.trim();
                boolean join=(isNumber(lt)&&isUnit(rt)) ||
                    (isCurrency(lt)&&isNumber(rt)) ||
                    (lt.matches("(?iu)C[O0]L|C[O0]P")&&isCurrencySymbol(rt));
                if(!join)continue;
                String text=lt+" "+rt;
                int leftX=Math.min(left.left,right.left),rightX=Math.max(left.right,right.right);
                int topY=Math.min(left.top,right.top),bottomY=Math.max(left.bottom,right.bottom);
                boolean duplicate=false;
                for(ScreenLine old:augmented) {
                    if(old.text.equalsIgnoreCase(text) && Math.abs(old.x()-(leftX+rightX)/2)<w*.02
                        && Math.abs(old.y()-(topY+bottomY)/2)<h*.02) {duplicate=true;break;}
                }
                if(duplicate)continue;
                for(ScreenLine old:additions) {
                    if(old.text.equalsIgnoreCase(text) && Math.abs(old.x()-(leftX+rightX)/2)<w*.02
                        && Math.abs(old.y()-(topY+bottomY)/2)<h*.02) {duplicate=true;break;}
                }
                if(!duplicate) {
                    int color=left.color!=COLOR_UNKNOWN?left.color:right.color;
                    additions.add(new ScreenLine(text,leftX,topY,rightX,bottomY,color));
                }
            }
            augmented.addAll(additions);
            if(additions.isEmpty())break;
        }
        return augmented;
    }

    private static final class Measure {
        final double value;final int x,y,color;
        Measure(double value,ScreenLine l){this.value=value;x=l.x();y=l.y();color=l.color;}
    }
    private static void collect(List<Measure> target,Pattern pat,ScreenLine l,double min,double max,int w,int h){
        for(Double value:measurements(pat,l.text,min,max)){
            boolean duplicate=false;
            for(Measure m:target)if(Math.abs(m.value-value)<.03 &&
                Math.abs(m.x-l.x())<w*.09 && Math.abs(m.y-l.y())<h*.025){
                duplicate=true;break;
            }
            if(!duplicate)target.add(new Measure(value,l));
        }
    }
    private static final class Pair {
        final Measure km,min;final int color;
        Pair(Measure km,Measure min){
            this.km=km;this.min=min;
            this.color=km.color!=COLOR_UNKNOWN?km.color:min.color;
        }
        int x(){return (km.x+min.x)/2;}
        int y(){return (km.y+min.y)/2;}
    }
    private static List<Pair> pairMap(List<Measure> kms,List<Measure> mins,int w,int h){
        List<Pair> pairs=new ArrayList<>();
        for(Measure km:kms){
            for(Measure min:mins){
                if(km.color!=COLOR_UNKNOWN && min.color!=COLOR_UNKNOWN && km.color!=min.color)continue;
                if(Math.abs(km.x-min.x)>w*.235 || Math.abs(km.y-min.y)>h*.078)continue;
                Pair pair=new Pair(km,min);
                boolean duplicate=false;
                for(Pair existing:pairs){
                    if(Math.abs(existing.km.value-km.value)<.03 &&
                        Math.abs(existing.min.value-min.value)<.03 &&
                        Math.abs(existing.x()-pair.x())<w*.10 &&
                        Math.abs(existing.y()-pair.y())<h*.035){
                        duplicate=true;break;
                    }
                }
                if(!duplicate)pairs.add(pair);
            }
        }
        return pairs;
    }
    private static double score(Pair pair,boolean pickup,int w,int h){
        double x=pair.x()/(double)w,y=pair.y()/(double)h;
        if(pair.color==COLOR_BLUE && !pickup)return -1000;
        if(pair.color==COLOR_LIME && pickup)return -1000;
        double s=0;
        if(pair.color==(pickup?COLOR_BLUE:COLOR_LIME))s+=70;
        if(pickup){
            if(x>.52 && x<.96)s+=24;
            if(y>.10 && y<.23)s+=22;
        }else{
            if(x>.08 && x<.60)s+=24;
            if(y>.17 && y<.33)s+=22;
        }
        if(pair.km.color==pair.min.color && pair.km.color!=COLOR_UNKNOWN)s+=12;
        s+=Math.max(0,10-Math.abs(pair.km.x-pair.min.x)/(double)w*35);
        return s;
    }
    private static void setPickup(Parsed p,Pair pair){
        p.pickupKm=pair.km.value;p.pickupMinutes=pair.min.value;
    }
    private static void setTrip(Parsed p,Pair pair){
        p.tripKm=pair.km.value;p.tripMinutes=pair.min.value;
    }
    private static boolean distinct(Pair a,Pair b,int w,int h){
        return a.km!=b.km && a.min!=b.min &&
            (Math.abs(a.x()-b.x())>w*.20 || Math.abs(a.y()-b.y())>h*.07);
    }
    private static void fillMap(Parsed p,List<Measure> kms,List<Measure> mins,int w,int h){
        List<Pair> pairs=pairMap(kms,mins,w,h);
        Pair bestP=null,bestT=null;double best=-1;
        for(Pair a:pairs)for(Pair b:pairs){
            if(!distinct(a,b,w,h))continue;
            double pscore=score(a,true,w,h),tscore=score(b,false,w,h);
            if(pscore<25||tscore<25)continue;
            // When color is unknown, demand the blue upper-right/green lower-left arrangement.
            if((a.color==COLOR_UNKNOWN||b.color==COLOR_UNKNOWN) &&
                !(a.x()>b.x()+w*.11 && a.y()<b.y()-h*.02))continue;
            double total=pscore+tscore;
            if(total>best){best=total;bestP=a;bestT=b;}
        }
        if(bestP!=null&&bestT!=null){
            setPickup(p,bestP);setTrip(p,bestT);
            p.minutes=p.pickupMinutes+p.tripMinutes;
            return;
        }
        // Partial extraction is useful to the driver, but may not be used for profit.
        if(pairs.size()==1){
            Pair only=pairs.get(0);
            double a=score(only,true,w,h),b=score(only,false,w,h);
            if(a>=55&&a>b+15)setPickup(p,only);
            else if(b>=55&&b>a+15)setTrip(p,only);
        }
    }
    private static final class Price {
        final double value;final int rank;
        Price(double value,int rank){this.value=value;this.rank=rank;}
    }
    private static Price price(ScreenLine l,int h){
        double y=l.y()/(double)h;
        if(y<.355||y>.745)return null;
        String s=l.text.toLowerCase(Locale.ROOT);
        if(COUNTER.matcher(s).find())return null;
        boolean accepted=s.contains("aceptar")||s.contains("acepta por");
        boolean card=y>=.385&&y<=.595;
        if(!card&&!accepted)return null;
        Double n=fareNumber(l.text,card);
        if(n==null)return null;
        int rank=card?100:40;
        if(l.text.matches("(?iu).*C[O0]L\\s*[$S].*"))rank+=20;
        if(accepted)rank+=5;
        return new Price(n,rank);
    }
    private static void fillFare(Parsed p,List<ScreenLine> lines,int h) {
        ArrayList<Price> candidates=new ArrayList<>();
        for(ScreenLine l:lines){Price q=price(l,h);if(q!=null)candidates.add(q);}
        if(candidates.isEmpty())return;
        candidates.sort(Comparator.comparingInt((Price q)->q.rank).reversed());
        Price primary=candidates.get(0);
        // A price on the main card and on the acceptance button should agree.
        for(Price q:candidates)if(q.rank>=40&&Math.abs(q.value-primary.value)>1){
            p.ambiguous=true;p.fare=null;return;
        }
        p.fare=primary.value;
    }

    /** Parses the actual coordinate-bearing ML Kit lines from the complete screen. */
    public static Parsed parseScreen(List<ScreenLine> source,int width,int height) {
        Parsed p=new Parsed();
        if(source==null || source.isEmpty() || width<=0 || height<=0){status(p);return p;}
        List<ScreenLine> lines=augment(source,width,height);
        StringBuilder all=new StringBuilder();
        List<Measure> kms=new ArrayList<>(),mins=new ArrayList<>();
        for(ScreenLine l:lines){
            all.append(l.text).append('\n');
            double y=l.y()/(double)height;
            if(y>=.075 && y<=.365){
                collect(kms,KM,l,0,250,width,height);
                collect(mins,MIN,l,1,300,width,height);
            }
        }
        p.offerVisible=MARKER.matcher(all).find();
        if(p.offerVisible){fillFare(p,lines,height);fillMap(p,kms,mins,width,height);}
        status(p);return p;
    }
}
