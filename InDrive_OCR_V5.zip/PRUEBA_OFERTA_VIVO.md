# Oferta usada para probar el reconocimiento (captura de usuario)

La pantalla muestra:

| Campo | Valor |
|---|---:|
| Tarifa principal | COP 21.800 |
| Recogida (recuadro azul) | 2,0 km, 12 min |
| Trayecto (recuadro verde) | 8,6 km, 25 min |
| Distancia total | 10,6 km |
| Tiempo total | 37 min |
| Contraofertas **no** principales | COP 22.800 y COP 24.000 |

Con los costos predeterminados del usuario, la ganancia operativa estimada es **COP 12.872** después de gasolina, gastos anuales prorrateados y comisión del 10,5 %, pero antes de asignar valor al tiempo de trabajo, depreciación, peajes y parqueaderos.

La implementación identifica campos OCR **por su posición**, no por el orden en que ML Kit emite las líneas. Se hicieron pruebas de orden aleatorio, resolución escalada, colores no identificados, datos fragmentados y precios incompatibles. En caso de falta de datos, no emite un resultado automático de rentabilidad.

**Limitación:** los datos de la prueba proceden de una transcripción de la captura compartida. No se afirma una prueba satisfactoria del OCR ejecutándose directamente en el Vivo hasta instalar la nueva APK y realizarla.
