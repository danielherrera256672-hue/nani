# Actualizar la APK existente desde GitHub (sin Android Studio)

## Método utilizado en tu repositorio `nani`

Tu repositorio de GitHub ya contiene `.github/workflows/main.yml`, que compila un ZIP llamado exactamente:

`Analizador_Vivo_APK_Compilacion_En_Nube.zip`

1. Descarga el **ZIP actualizado** que acompaña esta guía. **No lo descomprimas** para esta modalidad: el archivo `main.yml` ya se encarga de extraerlo.
2. Abre GitHub → repositorio **nani** → pestaña **Code** → **Add file → Upload files**.
3. Sube el nuevo `Analizador_Vivo_APK_Compilacion_En_Nube.zip` con **el mismo nombre** del anterior. Confirma la sustitución si GitHub la solicita. Si no permite sustituirlo, primero elimina el ZIP antiguo desde GitHub (botón `...` > Delete file > Commit), y luego sube el nuevo.
4. Pulsa **Commit changes** en la rama `main`.
5. En **Actions → Generar APK Android**, abre la ejecución más reciente. Si no arranca, entra en el workflow y elige **Run workflow**.
6. Comprueba que termine con una marca verde. En **Artifacts**, descarga `Analizador-Vivo-APK` (o el nombre que indique el workflow), extrae el archivo `app-debug.apk` y pásalo al Vivo.
7. Si Android dice **«No se pudo instalar»** debido a una firma diferente: guarda tus parámetros personalizados y **desinstala la APK anterior** antes de instalar esta. Las APK de depuración generadas en ejecuciones distintas de GitHub pueden tener firmas diferentes; desinstalar elimina los datos locales, pero todos tus costos iniciales ya vienen configurados.
8. En el teléfono, autoriza **Mostrar sobre otras apps**, vuelve a la aplicación, pulsa **Iniciar lectura automática (OCR)** y **autoriza la captura de pantalla completa**. Después abre inDrive y muestra una oferta.

### Validación tras instalar

El cuadro flotante deberá comenzar con **«Esperando lectura OCR»** y **los campos en blanco**, nunca con $15.000/2 km/6 km/25 min predefinidos. Si detecta todos los valores, muestra rentabilidad. Si falta uno, muestra **OCR parcial** y no califica automáticamente.

### Importante

- No cambia ni controla inDrive. Trabaja leyendo los píxeles de pantalla con permiso explícito del usuario.
- Revisa el resultado sin manipular el teléfono mientras conduces.
- El procesamiento y los cálculos son locales. No garantizamos que todas las ofertas o futuras versiones de la interfaz se interpreten correctamente.
