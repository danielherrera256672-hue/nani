# Analizador de Viajes — OCR corregido (Vivo V2206 / Funtouch OS 14)

**Versión de aplicación:** 5.0-vivo-ocr-mejorado (`versionCode=10`).

Aplicación Android local para evaluar ofertas visibles de inDrive después de autorizar la captura de pantalla. El proyecto no necesita conectarse a la cuenta del conductor, no pulsa botones de inDrive, no envía datos a servidores y no acepta viajes automáticamente.

## Qué cambia respecto a la versión anterior

- **Sin valores ficticios:** ya no se rellenan $15.000, 2 km, 6 km o 25 min cuando falla el OCR.
- **Detección por posición:** distingue el recuadro azul de recogida del recuadro verde de trayecto, sin depender del orden del texto extraído.
- **Tarifa correcta:** reconoce el precio principal en la tarjeta y en «Aceptar por»; ignora los botones de contraoferta.
- **OCR reforzado:** usa una lectura de pantalla completa y otras dos lecturas ampliadas, primero del mapa y después de la tarjeta de precios.
- **Fragmentos OCR:** interpreta números/unidades y precios separados en varios elementos.
- **Resultados conservadores:** solo muestra el semáforo automático cuando detecta tarifa, km de recogida, km de trayecto y los dos tiempos. Ante ausencia o contradicción, informa lectura parcial y permite corrección manual.
- **Captura visible y controlable:** al cerrar el panel flotante se detiene también la captura.
- **Costos correctos:** combustible, SOAT, seguros, tecnomecánica, llantas, mantenimiento y comisión editables.

## Datos predeterminados

- Combustible COP 140.000 / 8,4 galones y 40 km/galón: COP 416,67/km.
- Kilometraje anual: 17.000 km.
- SOAT COP 750.000/año, seguro de terceros COP 89.000/año, tecnomecánica COP 400.000/año.
- Llantas COP 650.000 cada 2 años; mantenimiento COP 2.000.000/año.
- Comisión inDrive 10,5 % de la tarifa.
- Total operativo sin comisión: aproximadamente COP 626,31/km.
- Metas de utilidad iniciales **provisionales y editables**: COP 5.000/viaje, COP 900/km y COP 12.000/h.

## Pruebas

`tests/FinancialTest.java` y `tests/OcrScreenTest.java` cubren el cálculo con la oferta real suministrada por el conductor y diversos patrones sintéticos de texto OCR con coordenadas. **No equivalen a una prueba del motor ML Kit sobre la pantalla real del Vivo**. La precisión en vivo dependerá de la versión de inDrive, tipografía, escala, permisos y superposiciones.

Para actualizar el ZIP que ya tienes en GitHub, consulta `ACTUALIZAR_NANI.md`. Para compilar el proyecto completo desde cero, consulta `.github/workflows/generar-apk.yml`.
