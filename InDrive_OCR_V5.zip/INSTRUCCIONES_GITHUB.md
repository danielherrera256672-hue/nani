# Compilar APK de prueba con GitHub Actions

Este proyecto está pensado para tu **Vivo V2206 / Funtouch OS 14**. El código de Java y las pruebas de OCR se compilan en GitHub Actions; el APK final es de depuración.

**Si ya tienes el repositorio `nani` con un workflow que abre el ZIP**, sigue `ACTUALIZAR_NANI.md` y sustituye únicamente el ZIP. No necesitas editar ni reemplazar el workflow existente.

Para compilar como proyecto normal en un repositorio nuevo:

1. Descomprime el ZIP.
2. Sube las carpetas `app`, `tests`, `.github` y los archivos `build.gradle`, `settings.gradle`, `gradle.properties` al directorio raíz de tu repositorio.
3. Comprueba que exista `.github/workflows/generar-apk.yml`.
4. En Actions abre **Generar APK Android** y ejecuta el workflow en la rama `main`.
5. En la ejecución verde, descarga el artifact **Analizador-Vivo-V2206-Android14-APK** y extrae `app-debug.apk`.

Si no compila, revisa el primer paso con X roja. Un error de Gradle o Java requerirá corrección antes de que exista un APK instalable.

**Nota de actualización:** las APK debug generadas en diferentes runners pueden usar diferentes certificados. Si no se instala encima de la anterior, desinstálala primero; la configuración local anterior se pierde, pero los valores de costo conocidos vuelven precargados.
