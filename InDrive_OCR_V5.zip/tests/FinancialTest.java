import com.local.ofertas.ProfitEngine;
import com.local.ofertas.OfferParser;

public final class FinancialTest {
    private static void checkNear(String label, double actual, double expected, double tol) {
        if(Math.abs(actual-expected)>tol) throw new AssertionError(label+": "+actual+" vs "+expected);
    }
    public static void main(String[] args) {
        ProfitEngine.Config c=new ProfitEngine.Config();
        checkNear("km por año",c.annualKilometers,17000,0.00001);
        checkNear("Combustible COP/km",c.fuelCostPerKm(),416.6666667,0.0001);
        checkNear("Gasto anual",c.annualTotalCosts(),3564000,0.0001);
        checkNear("Otros COP/km",c.annualCostPerKm(),209.6470588,0.0001);
        ProfitEngine.Offer o=new ProfitEngine.Offer();
        o.fare=21800;o.pickupKm=2;o.tripKm=8.6;o.totalMinutes=37;
        ProfitEngine.Result r=ProfitEngine.calculate(c,o);
        checkNear("Comisión",r.commission,2289,0.0001);
        checkNear("Combustible total",r.fuelCost,4416.666667,0.0001);
        checkNear("Gastos prorrateados",r.maintenanceCost+r.otherFixedCost,2222.258824,0.0001);
        checkNear("Utilidad",r.profit,12872.07451,0.0001);
        checkNear("km",r.totalKm,10.6,0.0001);
        checkNear("Tarifa mínima",r.minimumFareForTargets,18077.012,0.002);
        if(!"RENTABLE".equals(r.verdict)) throw new AssertionError("Semáforo esperado rentable");
        c.externalInsuranceIntervalMonths=1;
        ProfitEngine.Result moreCost=ProfitEngine.calculate(c,o);
        if(moreCost.profit>=r.profit)throw new AssertionError("Seguro mensual debe bajar utilidad");
        String text="Solicitud de viaje\n12 min\n2,0 km\n25 min\n8,6 km\nTen cuidado en esta ruta\nCOL$ 21.800\nPrecio justo\nAceptar por COL$ 21.800\nOfrece tu tarifa\nCOL$ 22.800\nCOL$ 24.000\nCerrar";
        OfferParser.Parsed p=OfferParser.parse(text);
        if(!p.complete())throw new AssertionError("OCR parse incompleto: "+p.warning);
        checkNear("Tarifa OCR",p.fare,21800,0.01);
        checkNear("Pickup OCR",p.pickupKm,2,0.01);
        checkNear("Trayecto OCR",p.tripKm,8.6,0.01);
        checkNear("Minutos OCR",p.minutes,37,0.01);
        // Prueba tambien la pantalla REAL con coordenadas, independientemente
        // de que ML Kit devuelva las lineas en otro orden.
        java.util.List<OfferParser.ScreenLine> screen=new java.util.ArrayList<>();
        screen.add(new OfferParser.ScreenLine("Solicitud de viaje",70,64,230,79,0));
        screen.add(new OfferParser.ScreenLine("12 min",198,91,231,105,OfferParser.COLOR_BLUE));
        screen.add(new OfferParser.ScreenLine("2,0 km",199,111,236,124,OfferParser.COLOR_BLUE));
        screen.add(new OfferParser.ScreenLine("25 min",88,131,127,145,OfferParser.COLOR_LIME));
        screen.add(new OfferParser.ScreenLine("8,6 km",89,151,128,165,OfferParser.COLOR_LIME));
        screen.add(new OfferParser.ScreenLine("COL$ 21.800",45,272,148,285,0));
        screen.add(new OfferParser.ScreenLine("Precio justo",169,270,251,284,0));
        screen.add(new OfferParser.ScreenLine("Aceptar por COL$ 21.800",50,422,238,438,0));
        screen.add(new OfferParser.ScreenLine("Ofrece tu tarifa",110,468,232,482,0));
        screen.add(new OfferParser.ScreenLine("COL$ 22.800",36,516,137,532,0));
        screen.add(new OfferParser.ScreenLine("COL$ 24.000",152,516,253,532,0));
        java.util.Collections.shuffle(screen,new java.util.Random(37));
        OfferParser.Parsed real=OfferParser.parseScreen(screen,290,632);
        if(!real.complete())throw new AssertionError("OCR por coordenadas incompleto: "+real.warning);
        checkNear("Tarifa posicion",real.fare,21800,0.01);
        checkNear("Recogida posicion",real.pickupKm,2,0.01);
        checkNear("Trayecto posicion",real.tripKm,8.6,0.01);
        checkNear("Tiempo posicion",real.minutes,37,0.01);
        screen.removeIf(l->l.text.equals("12 min"));
        if(OfferParser.parseScreen(screen,290,632).complete())
            throw new AssertionError("No se puede calificar sin tiempo de recogida");
        System.out.println("OK: calculos y OCR por texto y coordenadas, datos reales, contraofertas y faltantes");
    }
}
