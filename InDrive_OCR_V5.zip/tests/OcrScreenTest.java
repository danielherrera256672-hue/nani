import com.local.ofertas.OfferParser;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public final class OcrScreenTest {
    private static final int W=290,H=632;
    private static OfferParser.ScreenLine l(String s,int x,int y,int width,int color) {
        return new OfferParser.ScreenLine(s,x,y,x+width,y+12,color);
    }
    private static void check(String what,boolean ok){if(!ok)throw new AssertionError(what);}
    private static void near(String what,Double a,double b){
        if(a==null || Math.abs(a-b)>0.05)throw new AssertionError(what+" got "+a+" expected "+b);
    }
    private static List<OfferParser.ScreenLine> real(){
        List<OfferParser.ScreenLine> a=new ArrayList<>();
        a.add(l("Solicitud de viaje",72,65,150,0));
        a.add(l("12 min",202,93,31,OfferParser.COLOR_BLUE));
        a.add(l("2,0 km",202,113,36,OfferParser.COLOR_BLUE));
        a.add(l("25 min",90,133,35,OfferParser.COLOR_LIME));
        a.add(l("8,6 km",90,153,41,OfferParser.COLOR_LIME));
        a.add(l("Ten cuidado en esta ruta",65,194,200,0));
        a.add(l("~2,0 km",47,257,60,0)); // KM de la ficha, NO mapa
        a.add(l("COL$ 21.800",48,276,100,0));
        a.add(l("Precio justo",167,276,85,0));
        a.add(l("Aceptar por COL$ 21.800",49,424,196,0));
        a.add(l("Ofrece tu tarifa",100,470,128,0));
        a.add(l("COL$ 22.800",36,520,104,0));
        a.add(l("COL$ 24.000",155,520,100,0));
        return a;
    }
    private static void checkReal(OfferParser.Parsed p){
        check("debe tener oferta",p.offerVisible);
        check("completa: "+p.warning,p.complete());
        near("tarifa",p.fare,21800);
        near("recogida km",p.pickupKm,2);
        near("viaje km",p.tripKm,8.6);
        near("recogida min",p.pickupMinutes,12);
        near("viaje min",p.tripMinutes,25);
        near("total min",p.minutes,37);
    }
    public static void main(String[] args){
        List<OfferParser.ScreenLine> original=real();
        checkReal(OfferParser.parseScreen(original,W,H));
        Collections.shuffle(original,new java.util.Random(42));
        checkReal(OfferParser.parseScreen(original,W,H));
        // La moneda viene dividida en dos elementos OCR, pero en la misma fila.
        List<OfferParser.ScreenLine> splitFare=real();
        splitFare.removeIf(l->l.text.equals("COL$ 21.800"));
        splitFare.add(l("COL$",48,276,33,0));
        splitFare.add(l("21.800",82,276,62,0));
        checkReal(OfferParser.parseScreen(splitFare,W,H));
        // Ampliacion de mapa, parte de un valor fragmentado.
        List<OfferParser.ScreenLine> splitMap=real();
        splitMap.removeIf(l->l.text.equals("8,6 km"));
        splitMap.add(l("8,6",90,153,22,OfferParser.COLOR_LIME));
        splitMap.add(l("km",114,153,17,OfferParser.COLOR_LIME));
        checkReal(OfferParser.parseScreen(splitMap,W,H));
        // Nunca completar una oferta si falta la duracion de recogida.
        List<OfferParser.ScreenLine> missing=real();
        missing.removeIf(l->l.text.equals("12 min"));
        OfferParser.Parsed partial=OfferParser.parseScreen(missing,W,H);
        check("falta un tiempo: "+partial.warning,!partial.complete());
        check("no debe inventarse el tiempo",partial.minutes==null);
        check("faltantes expresos",partial.warning.contains("min de recogida"));
        // No es una oferta: no usar precios encontrados en otras pantallas.
        List<OfferParser.ScreenLine> noOffer=Arrays.asList(
            l("COL$ 21.800",49,276,94,0), l("Cerrar",55,470,65,0));
        check("sin oferta no califica",!OfferParser.parseScreen(noOffer,W,H).complete());
        // No confundir el boton de contraoferta con la tarifa principal.
        List<OfferParser.ScreenLine> counters=real();
        counters.removeIf(l->l.text.equals("COL$ 21.800") || l.text.equals("Aceptar por COL$ 21.800"));
        OfferParser.Parsed noMain=OfferParser.parseScreen(counters,W,H);
        check("sin tarifa principal no califica",!noMain.complete());
        check("no debe tomar COL$22.800",noMain.fare==null);
        // Tres elementos OCR para la moneda; el parser necesita dos pasadas.
        List<OfferParser.ScreenLine> triplePrice=real();
        triplePrice.removeIf(l->l.text.equals("COL$ 21.800"));
        triplePrice.add(l("COL",48,276,26,0));
        triplePrice.add(l("$",76,276,6,0));
        triplePrice.add(l("21.800",85,276,59,0));
        checkReal(OfferParser.parseScreen(triplePrice,W,H));
        // El OCR puede detectar el color de fondo como desconocido.
        List<OfferParser.ScreenLine> noColor=new ArrayList<>();
        for(OfferParser.ScreenLine line:real())noColor.add(new OfferParser.ScreenLine(
            line.text,line.left,line.top,line.right,line.bottom,0));
        checkReal(OfferParser.parseScreen(noColor,W,H));
        // Dispositivo de mayor resolución: las coordenadas deben ser proporcionales.
        List<OfferParser.ScreenLine> big=new ArrayList<>();
        for(OfferParser.ScreenLine line:real())big.add(new OfferParser.ScreenLine(
            line.text,line.left*4,line.top*4,line.right*4,line.bottom*4,line.color));
        checkReal(OfferParser.parseScreen(big,W*4,H*4));
        // Un valor distinto en el botón de aceptar debe invalidar la lectura.
        List<OfferParser.ScreenLine> mismatch=real();
        mismatch.removeIf(l->l.text.equals("Aceptar por COL$ 21.800"));
        mismatch.add(l("Aceptar por COL$ 18.800",49,424,196,0));
        OfferParser.Parsed conflict=OfferParser.parseScreen(mismatch,W,H);
        check("precios contradictorios no deben calificarse",!conflict.complete());
        // No inventar la distancia de recogida si no está visible.
        List<OfferParser.ScreenLine> missingPickup=real();
        missingPickup.removeIf(l->l.text.equals("2,0 km"));
        OfferParser.Parsed partialPickup=OfferParser.parseScreen(missingPickup,W,H);
        check("km de recogida ausente",!partialPickup.complete());
        System.out.println("OK: mapa real; OCR desordenado/fragmentado; 3 tokens de tarifa; " +
            "sin color; resolucion variable; campos incompletos; precios contradictorios y contraofertas");
    }
}
